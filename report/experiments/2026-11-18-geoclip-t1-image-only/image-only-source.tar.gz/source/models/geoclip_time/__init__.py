"""Time-conditioned GeoCLIP experiments."""
